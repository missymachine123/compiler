//function
fun myFunction() {
  println("I just got executed!")
}
fun main() {
  myFunction() // Call myFunction
}