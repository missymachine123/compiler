//loops
fun main() {

    for (i in 1..5) {
        println(i)
    }

    val name = "stranger"        // Declare your first variable
    println("Hi, $name!")        // ...and use it!
    print("Current count:")
    for (i in 0..10) {           // Loop over a range from 0 to 10
        print(" $i")
    }

    var x = 5
    while (x > 0) {
        println(x)
        x--
    }


 }