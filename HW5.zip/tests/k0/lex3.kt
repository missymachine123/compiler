fun main() {
    var x = 1975 
    x = x + 1 
    x = x * 2 
    x = x / 2 
    x = x % 2 
    x = x - 1 
    x++ 
    --x
     
    
    // x += 1
    // println(x)
    // x -= 1
    // println(x)
    // x *= 2
    // println(x)
    // x /= 2
    // println(x)
    // x %= 2

}