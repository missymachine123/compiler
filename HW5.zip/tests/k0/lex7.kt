fun main() {
    // Sample test inputs
    const val WEBSITE_NAME = "Baeldung"
    for ( x in y..z) {}


    val inputs = listOf("import", "const", "interface", "class", "fun")
 
}
interface MyInterface {
    fun bar()
    fun foo() {
      // optional body
    }
}
import kotlin.math.PI
fun alctoken(tokenType: String): String {
    return tokenType
}