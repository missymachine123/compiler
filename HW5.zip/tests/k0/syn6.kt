//operators
fun main() {  
  var x = 10
  var x = 100 + 50
  var y = 3
  1 + 3 
  100 - 2
  100*2
  10/2
  30%2
  ++x
  x++
  --x
  x--
  println(x + y)
  println(x - y)
  println(x * y)  
  println(x % y)  
  println(x == y)
  println(x != y)
  println(x > y)
  println(x < y)
  println(x <= y)
  println(x >= y)
  println(x > 3 && x < 10)
  println(x > 3 || x < 4)
  var myBool = true
  println(!myBool)
}