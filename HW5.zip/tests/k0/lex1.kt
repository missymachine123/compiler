fun main() {
    var name = "John"
    val birthyear = 1975
    println(name)          // Print the value of name
    println(birthyear)     // Print the value of birthyear
    val name = "Kotlin"
    println(name.length) // Accesses the 'length' property of the String object
}