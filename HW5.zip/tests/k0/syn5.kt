//function parameteres 
fun myFunction(fname: String) {
  println(fname + " Doe")
}

fun myFunction2(fname: String, age: Int) {
  println(fname + " is " + age)
}

fun myFunction3(x: Int, y: Int): Int {
  return (x + y)
}

fun main() {
  myFunction("John")

}



