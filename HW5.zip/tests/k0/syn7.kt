//Strings, bool
fun main() {
  var greeting = "Hello"
  var greeting: String = "Hello"
  var txt1 = "It's alright"
  var txt2 = "That's great"

  val isKotlinFun = true
  val isFishTasty = false
  val isKotlinFun: Boolean = true
  val isFishTasty: Boolean = false

}