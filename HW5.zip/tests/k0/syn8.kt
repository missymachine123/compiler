//array
fun main() {
  var a : Array<Int> = Array<Int>(8) {0}
  a[5] = 5
  println(a[5])
}