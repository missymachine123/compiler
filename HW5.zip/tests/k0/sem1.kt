val n1 : Int = 0
val n2 : Int = 0

fun f(n1 : Double) {
   var n2 : Double = 0.0
   var y : Int = 0

   var n1 : Double = 3.14
   var n2 : String
   println(n1)
}