fun main (){
    val myNum: Int = 5                // Int
    val myDoubleNum: Double = 5.99    // Double
    val myBoolean: Boolean = true     // Boolean
    val boolean: Boolean = false    // Boolean
    val myText: String = "Hello"      // String
    val myFloat: Float = 19.99f       // Float
    val myLong: Long = 150000000L   // Long
    val myShort: Short = 5000         // Short
    val myByte: Byte = 100            // Byte
    val myLetter: Char = 'D'          // Char
}