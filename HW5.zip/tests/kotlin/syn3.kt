class MyClass {
    fun greet() = println("Hello from MyClass")
}

fun main() {
    val myClassInstance = MyClass()
    myClassInstance.greet()
}