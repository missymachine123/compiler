package myPackage

fun greet() {
    println("Hello from myPackage!")
}

fun main() {
    greet()  // Should print "Hello from myPackage!"
}