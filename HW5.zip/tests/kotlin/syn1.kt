fun main() {
    val x: Any = "Hello"
    val y = x as String
}