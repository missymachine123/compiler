fun main() {
    val x: Any = "Hello"
    val y: String? = x as? String
}