fun main() {
    val x = 10
    println(typeof(x))  // Should print the type of x, e.g., "Int"
}