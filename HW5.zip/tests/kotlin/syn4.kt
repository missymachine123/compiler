fun main() {
    val x = 5
    if (x !in 1..10) {
        println("x is not in the range 1 to 10")
    } else {
        println("x is in the range 1 to 10")
    }
}