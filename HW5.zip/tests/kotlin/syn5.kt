fun main() {
    val x: Any = "Hello"
    if (x is String) {
        println("x is a String")
    }
}