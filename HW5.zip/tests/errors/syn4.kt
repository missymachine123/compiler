fun main() {
    println "Hello, World!" // Missing parentheses in function call
}