for (val i in 1..5) { // `val` cannot be used here
    println(i)
}