fun main() {
    var i = 0
    do {
      println(i)
      i++
      }
    while (i < 5) 
}