fun main() {
    val a = 5
    if (a > 3) {
        println("a is greater than 3")
    // Missing closing brace