//undeclared variable
fun main() {
    println(variable)
}