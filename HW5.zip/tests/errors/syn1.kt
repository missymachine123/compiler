fun main { // Missing parentheses
    println("Hello, World!")
}