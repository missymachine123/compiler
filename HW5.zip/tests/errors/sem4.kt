//modifying val
fun main() {
    val x = 5
    x = 10 // Error: `val` cannot be reassigned
}