//variable used before initialized
fun main() {
    println(x) 
    val x = 5
}