when { // Missing argument after when
    x == 1 -> println("One")
}