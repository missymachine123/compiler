   fun main()
   {
   var i : Int = 0;

   while (i > 20) {
      i = i * i + 1;
      }
   println("$i");
   }