fun main()
   {
   var i : Int = 0;
   var s : String = "Hello, World!";

   while (i > 20) {
      i = i * i + 1;
      }
   println("$i");
   }