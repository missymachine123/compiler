
val s : Int = 1;

val myNum: Int =5                // Int
val myDoubleNum: Double = 5.99    // Double
val myBoolean: Boolean = true     // Boolean
val boolean: Boolean = false    // Boolean
val myText: String = "Hello"      // String
val myFloat: Float = 19.99f       // Float
val myLong: Long = 15000000000   // Long
val myShort: Short = 5000         // Short
val myByte: Byte = 100            // Byte
val myLetter: Char = 'D'          // Char
fun assignments() {
    val a : Int = 1;
    val b : Int = 2;
    val c : Int = 3;
     
 }
 
 fun Operators() {
 var w : Int = 0;
 var s : String = "hi";
 var x : Int;
 var y : Int = 0;
 val z : Int =0;
 val q : Int =0;
 x = 1; }